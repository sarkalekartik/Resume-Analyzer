import re
from skills import SKILLS

def analyze_resume(text):
    text = text.lower()

    matched_skills = [s for s in SKILLS if s in text]

    experience = 0
    match = re.search(r'(\d+)\s+years?', text)
    if match:
        experience = int(match.group(1))

    score = (len(matched_skills) * 8) + (experience * 5)
    score = min(score, 100)

    return {
        "skills": matched_skills,
        "experience": experience,
        "ats_score": score
    }

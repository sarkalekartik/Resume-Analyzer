SKILLS = [
    "python",
    "java",
    "sql",
    "machine learning",
    "artificial intelligence",
    "ai",
    "html",
    "css",
    "javascript",
    "react",
    "node",
    "flask",
    "django",
    "data analysis"
]

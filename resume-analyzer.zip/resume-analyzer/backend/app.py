from flask import Flask, request, jsonify
from flask_cors import CORS
import pdfplumber
from docx import Document
from analyzer import analyze_resume

app = Flask(__name__)
CORS(app)

def extract_text(file):
    if file.filename.endswith(".pdf"):
        text = ""
        with pdfplumber.open(file) as pdf:
            for page in pdf.pages:
                if page.extract_text():
                    text += page.extract_text()
        return text

    elif file.filename.endswith(".docx"):
        doc = Document(file)
        return " ".join(p.text for p in doc.paragraphs)

    return ""

@app.route("/analyze", methods=["POST"])
def analyze():
    if "resume" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["resume"]
    text = extract_text(file)

    if not text.strip():
        return jsonify({"error": "Text extraction failed"}), 400

    result = analyze_resume(text)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)

async function analyzeResume() {
    const fileInput = document.getElementById("resume");
    const resultDiv = document.getElementById("result");

    if (!fileInput.files.length) {
        alert("Upload resume first");
        return;
    }

    const formData = new FormData();
    formData.append("resume", fileInput.files[0]);

    const response = await fetch("http://127.0.0.1:5000/analyze", {
        method: "POST",
        body: formData
    });

    const data = await response.json();

    resultDiv.innerHTML = `
        <h3>ATS Score: ${data.ats_score}</h3>
        <p><b>Experience:</b> ${data.experience} years</p>
        <p><b>Skills:</b> ${data.skills.join(", ")}</p>
    `;
}
